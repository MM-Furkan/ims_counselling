import { LightningElement } from 'lwc';

export default class Iframe extends LightningElement {}